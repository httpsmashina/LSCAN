==========================================================
INSTALL INSTRUCTIONS:
==========================================================
chmod +x installer.sh
./installer.sh

==========================================================
UPDATE INSTRUCTIONS:
==========================================================
chmod +x updater.sh
./updater.sh
(or run the update option in the script)
